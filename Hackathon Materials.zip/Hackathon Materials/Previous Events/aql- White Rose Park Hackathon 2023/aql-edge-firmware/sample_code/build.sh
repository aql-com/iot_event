#!/bin/bash

idf.py build