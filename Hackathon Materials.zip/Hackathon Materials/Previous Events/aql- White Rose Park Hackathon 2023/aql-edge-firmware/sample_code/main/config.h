// ***************
// * config.h
// ***************

// This file is overwritten when project variant is changed!

// #include the project variant .h file:
// format is: <path_from_main>/filename.h

#include "Customer_h/MAC_Rpt_Gateway_01.h"
