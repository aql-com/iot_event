//////////////////////////////////////////////
//
// MAC_Rpt_four_g.h
//
// aql Ltd
//
// Auth: DLT
//
//////////////////////////////////////////////

#ifndef MAC_RPT_FOUR_G_HTTP_H
#define MAC_RPT_FOUR_G_HTTP_H


void four_g_http_state_machine(unsigned char *four_g_state,unsigned char *prev_four_g_state);


#endif
