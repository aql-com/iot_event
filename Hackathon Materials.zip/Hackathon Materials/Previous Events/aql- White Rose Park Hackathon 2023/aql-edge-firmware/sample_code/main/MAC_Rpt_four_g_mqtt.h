//////////////////////////////////////////////
//
// MAC_Rpt_four_g_mqtt.h
//
// aql Ltd
//
// Auth: DLT
//
//////////////////////////////////////////////

// new code for separate SIMCOM, MQTT and UDP modes

#ifndef FOUR_G_MQTT_H
#define FOUR_G_MQTT_H

#include "MAC_Rpt.h"

void four_g_mqtt_state_machine(unsigned char *mqtt_state,unsigned char *prev_mqtt_state, unsigned char *simcom_state);
unsigned char mqtt_check_topic_str(void);
void print_mqtt_state(unsigned char chan);
void print_mqtt_login_state(unsigned char chan);

enum MQTT_STATES
{
MQTT_NO_COMM_IDLE,			// (system WAIT) <= goes to MQTT_CHECKS_ERROR_END -> MQTT_GET_MODULETYPE:	error_attempts = 0;
// comms init
MQTT_COMM_INIT,
MQTT_CLOSEALL,
MQTT_CHECK_SIG_QUALITY,
MQTT_CHECK_OPS_1,
MQTT_CHECK_4G_NETWORK,
MQTT_CHECK_GPRS_NETWORK,
MQTT_CHECK_OPS,
MQTT_CHECK_RELEASE,
MQTT_CHECK_STOP,
MQTT_SET_PDP,
MQTT_ACT_PDP,				// THIS STATE NOT USED! error_attempts = 0;

MQTT_SET_SSL_CONFIG,
MQTT_SET_SSL_AUTHMODE,
MQTT_LOAD_SSL_SERVER_CERTIFICATE,
MQTT_LOAD_SSL_CLIENT_CERTIFICATE,
MQTT_LOAD_SSL_CLIENT_KEY,
MQTT_SHOW_SSL_CERTIFICATES,
MQTT_SET_SSL_SERVER_CERTIFICATE,
MQTT_SET_SSL_CLIENT_CERTIFICATE,
MQTT_SET_SSL_CLIENT_KEY,		// WAS error_attempts = 0;

MQTT_COMM_START,				// (not a system WAIT) <= goes to MQTT_COMMS_INIT_ERROR_END -> MQTT_COMM_INIT:	error_attempts = 0;
// connect
MQTT_ACQUIRE_CLIENT,
MQTT_SET_WILLTOPIC,
MQTT_SET_WILLMSG,
MQTT_SET_UTF8_MODE,		// WAS error_attempts = 0;
MQTT_CONNECT,			// (not a system WAIT) <= goes to MQTT_CONNECT_ERROR_END -> MQTT_ACQUIRE_CLIENT:	error_attempts = 0;
MQTT_CONNECT_CHECK,
// send \ receive
MQTT_SET_SUBSCRIBE_TOPIC,
MQTT_SUBSCRIBE_TOPIC,
MQTT_SUBSCRIBE_MSG,
MQTT_SET_TOPIC,
MQTT_SET_PAYLOAD,
MQTT_PUBLISH_MSG,		// WAS error_attempts = 0;

MQTT_CONNECT_IDLE,			// (system WAIT) <= goes to MQTT_SEND_RCV_ERROR_END -> MQTT_SET_TOPIC:	error_attempts = 0;
// disconnect
MQTT_UNSUBSCRIBE_TOPIC,	// > MQTT_CONNECT_IDLE goes to MQTT_DISC_PWRDOWN_ERROR_END -> MQTT_POWER_DOWN_KEY
MQTT_SERVER_DISCONNECT,
MQTT_CLIENT_RELEASE,
MQTT_STOP,

MQTT_COMM_IDLE,				//  (system WAIT)

MQTT_IDLE_CHECK_4G_NET,
MQTT_IDLE_CHECK_SIG_QUALITY,

MQTT_POWER_UP_ERROR_END,
MQTT_CHECKS_ERROR_END,
MQTT_COMMS_INIT_ERROR_END,
MQTT_CONNECT_ERROR_END,
MQTT_SEND_RCV_ERROR_END,
MQTT_DISC_PWRDOWN_ERROR_END,
MQTT_END,
MQTT_NO_ERROR,
MQTT_NUM_STATES
};

const char mqtt_state_str[MQTT_NUM_STATES][32] = 
{
//        1         2         3
//234567890123456789012345678901

"NO_COMM_IDLE",

"COMM_INIT",

"CLOSEALL",
"CHECK_SIG_QUALITY",
"CHECK_OPS_1",
"CHECK_4G_NETWORK",
"CHECK_GPRS_NETWORK",
"CHECK_OPS",
"CHECK_RELEASE",
"CHECK_STOP",
"SET_PDP",
"ACT_PDP",

"SET_SSL_CONFIG",
"SET_SSL_AUTHMODE",
"LOAD_SSL_SERVER_CERTIFICATE",
"LOAD_SSL_CLIENT_CERTIFICATE",
"LOAD_SSL_CLIENT_KEY",
"SHOW_SSL_CERTIFICATES",

"SET_SSL_SERVER_CERTIFICATE",
"SET_SSL_CLIENT_CERTIFICATE",
"SET_SSL_CLIENT_KEY",

"COMM_START",

"ACQUIRE_CLIENT",
"SET_WILLTOPIC",
"SET_WILLMSG",
"SET_UTF8_MODE",
"CONNECT",
"CONNECT_CHECK",
"SET_SUBSCRIBE_TOPIC",
"SUBSCRIBE_TOPIC",
"SUBSCRIBE_MSG",
"SET_TOPIC",
"SET_PAYLOAD",
"PUBLISH_MSG",

"CONNECT_IDLE",

"UNSUBSCRIBE_TOPIC",
"SERVER_DISCONNECT",
"CLIENT_RELEASE",
"STOP",

"COMM_IDLE",

"IDLE_CHECK_4G_NET",
"IDLE_SIG_QUALITY",

"POWER_UP_ERROR",
"CHECKS_ERROR",
"COMMS_INIT_ERROR",
"CONNECT_ERROR",
"SEND_RCV_ERROR",
"DISC_PWRDOWN_ERROR",
"END",
"NO_ERROR"
};

/*
const char nmea_cmd_list[NMEA_CMD_LIST_LENGTH][NMEA_CMD_LIST_ENTRY_LENGTH] = 
{
//234567890
"$PGPPADV",
"$GPGBS",
"$GPGGA",
"$GPGSA"	
};
*/
#define ADDR_AND_PORT_LEN	100



#define FOUR_G_POWER_EN_WAIT		   	   2	// 200msec
#define FOUR_G_RESET_WAIT				   5 	// 500msec
#define FOUR_G_POWER_ON_WAIT			   5 	// 500msec
#define FOUR_G_POWER_ON_RESP_WAIT		 160 	// 16 sec
#define FOUR_G_POWER_DOWN_KEY_WAIT		  25	// 2.5 sec
#define FOUR_G_POWER_DOWN_RESP_WAIT		  10	// 1 sec 	// 260	// 26 sec
#define COMM_DELAY						  20	//10	// 1 sec
#define COMM_TIMEOUT					  20	//10	// 0.5 sec
#define COMM_LONG_TIMEOUT				  40	//20	// 1 sec
#define COMM_VLONG_TIMEOUT				  60	//30	// 1 sec
#define COMM_CERT_TIMEOUT				 100	//40	// 3 sec
#define COMM_PUBLISH_TIMEOUT			 200	//30	// 1 sec
#define COMM_CONN_TIMEOUT				 200	// 3 sec
#define COMM_TIMEOUT_DEFEAT			  0xFFFF	// long as possible...
#define COMM_PHASE_RETRIES				   2	// 1 attempt + 2 retries
#define ERROR_RETRIES				   	   2	// 1 attempt + 2 retries
#define MQTT_MAX_ERROR_RETRIES		       5	//10	// 1 attempt + 9 retries

#define MQTT_SENSOR_TIME				  30	// 180sec = 3 min

#define MQTT_PAYLOAD_SIZE				 8192	// max 10240

#endif