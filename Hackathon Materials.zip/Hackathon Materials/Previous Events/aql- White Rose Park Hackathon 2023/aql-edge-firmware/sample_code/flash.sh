#!/bin/bash

idf.py -p/dev/cu.usbserial-14210 flash
