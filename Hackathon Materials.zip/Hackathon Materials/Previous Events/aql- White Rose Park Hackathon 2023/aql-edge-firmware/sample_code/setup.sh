#!/bin/bash

. $HOME/esp/esp-idf/export.sh