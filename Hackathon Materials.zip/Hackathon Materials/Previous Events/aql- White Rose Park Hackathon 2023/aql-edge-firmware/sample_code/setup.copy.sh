#!/bin/bash

echo ####################################
echo # STARTING COMPILER ENVIRONMENT...
echo # MAC RPT...
echo ####################################

./esp-idf/tools/install.sh esp32/tool_setup/idf_cmd_init_copy.sh  "/Library/Frameworks/Python.framework/Versions/3.10/bin/python3" "/usr/bin/git"




